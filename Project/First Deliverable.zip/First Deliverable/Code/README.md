# Building 
```
cc lexer.c
```

# Running 

./a.out

## Notes 
- Accepts input files of any format 
- Will give a line by line showing  of all tokens
- Will return count of tokens 
